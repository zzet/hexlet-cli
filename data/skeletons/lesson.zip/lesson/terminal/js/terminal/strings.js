/* global define */

define({
  en: {
    translation: {
    }
  },

  ru: {
    translation: {
    }
  }
});
